# Dependencias:

`sudo apt install clang erlang`
#ifndef __PROTO_H
#define __PROTO_H 1

#include "common.h"


void text_handle1(struct eventloop_data *evd, struct cinfo *ci,
		  const char *buf, int len);

#endif
